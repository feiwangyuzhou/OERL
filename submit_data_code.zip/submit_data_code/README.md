# OERL: Enhanced Representation Learning via Open Knowledge Graphs

Dataset and code for our paper: Enhanced Representation Learning via Open Knowledge Graphs.

### Dataset two KGs and one OKG:
* CN100K and OEKG: 
  
  kg_entity2id.txt: all entities and corresponding ids, one per line.

  kg_relation2id.txt: all relations and corresponding ids, one per line.

  kg_train.txt: training file with ids, in the format ***(h,r,t)*** which indicates there is a relation ***r*** between entity ***h*** and ***t*** .
  
  kg_valid.txt: validating file with ids, in the same format ***(h,r,t)*** with the train.txt.
  
  kg_test.txt: testing file with ids, in the same format ***(h,r,t)*** with the train.txt.

* OLPBENCH-OKG:

  entity2id.txt: all entities and corresponding ids, one per line.

  relation2id.txt: all relations and corresponding ids, one per line.

  train.txt: training file with ids, in the format ***(h,r,t)*** which indicates there is a relation ***r*** between entity ***h*** and ***t*** .
  
  valid.txt: validating file with ids, in the same format ***(h,r,t)*** with the train.txt.
  
  test.txt: testing file with ids, in the same format ***(h,r,t)*** with the train.txt.


### Code OEKGRL_EM_GAT:
* Compatible with Pytorch 1.1 and Python 3.x.
* Run the code: `python main.py -dataset OEKG -lr 0.00005 -batch_size 128`.



