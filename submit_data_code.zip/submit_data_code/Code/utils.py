import numpy as np
import random
import copy
import time

import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.cuda as cuda
import torch.optim as optim
import torch.nn.functional as F
import math

import warnings
warnings.filterwarnings("ignore")
import pdb

def seq_batch(phrase_id, args, phrase2word):
    phrase_batch = np.ones((len(phrase_id),32),dtype = int)*args.pad_id
    phrase_len = torch.LongTensor(len(phrase_id))
    
    for i,ID in enumerate(phrase_id):
        # print(len(phrase2word[ID]))
        # print(len(np.array(phrase2word[ID])))
        phrase_batch[i,0:len(phrase2word[ID])] = np.array(phrase2word[ID])
        phrase_len[i] = len(phrase2word[ID])
        
    phrase_batch = torch.from_numpy(phrase_batch)
    phrase_batch = Variable(torch.LongTensor(phrase_batch))
    phrase_len = Variable(phrase_len)
    
    if args.use_cuda:
        phrase_batch = phrase_batch.cuda()
        phrase_len = phrase_len.cuda()
    
    return phrase_batch, phrase_len

def nofilter_edges_batch(edges_ent_batch_temp):
    edges_ent_batch = []
    edges_rel_batch = []
    head_list = []
    tail_list = []
    for ent_tail in edges_ent_batch_temp:
        for ent_head in edges_ent_batch_temp[ent_tail]:
                head_list.append(ent_head)
                tail_list.append(ent_tail)
    edges_ent_batch.append(head_list)
    edges_ent_batch.append(tail_list)
    edges_ent_batch = torch.LongTensor(edges_ent_batch).cuda()
    return edges_ent_batch

def filter_edges_batch(edges_ent_batch_temp, unique_ent_batch):
    edges_ent_batch = []
    edges_rel_batch = []
    head_list = []
    tail_list = []
    for ent_tail in edges_ent_batch_temp:
        for ent_head in edges_ent_batch_temp[ent_tail]:
            if ent_head in unique_ent_batch:
                head_list.append(ent_head)
                tail_list.append(ent_tail)
    edges_ent_batch.append(head_list)
    edges_ent_batch.append(tail_list)
    edges_ent_batch = torch.LongTensor(edges_ent_batch).cuda()

    return edges_ent_batch

def get_next_batch(id_list, data, args, train, okgEntitytext_max_num = 32):
    entTotal = args.num_nodes
    samples = []
    samples_trips = []

    C_h_all = data.C_h_all
    C_r_all = data.C_r_all
    S_okg_all = data.S_okg_all
    S_kg_all = data.S_kg_all

    true_rel_len = len(data.rel2id) // 2

    pad_id = data.word2id['<PAD>']
    C_h_text = np.ones((len(id_list), okgEntitytext_max_num, 24), dtype=int) * pad_id
    C_h_text_len = np.zeros((len(id_list), okgEntitytext_max_num), dtype=int)
    C_h_text_mask = np.zeros((len(id_list), okgEntitytext_max_num), dtype=int)
    C_r_text = np.ones((len(id_list), okgEntitytext_max_num, 16), dtype=int) * pad_id
    C_r_text_len = np.zeros((len(id_list), okgEntitytext_max_num), dtype=int)
    C_r_text_mask = np.zeros((len(id_list), okgEntitytext_max_num), dtype=int)

    S_okg_text = np.ones((len(id_list), okgEntitytext_max_num, 26), dtype=int) * pad_id
    S_okg_text_len = np.zeros((len(id_list), okgEntitytext_max_num), dtype=int)
    S_okg_text_mask = np.zeros((len(id_list), okgEntitytext_max_num), dtype=int)

    S_kg_id = np.ones((len(id_list), okgEntitytext_max_num, 3), dtype=int) * pad_id
    S_kg_id_mask = np.zeros((len(id_list), okgEntitytext_max_num), dtype=int)

    # pdb.set_trace()
    labels = np.zeros((len(id_list),entTotal))
    for i in range(len(id_list)):
        # pdb.set_trace()
        trip = train[id_list[i]]
        samples.append([trip[0],trip[1]])
        pos_ids = list(data.label_graph[(trip[0],trip[1])])
        labels[i][pos_ids] = 1
        for tt in pos_ids:
            samples_trips.append([trip[0],trip[1],tt])

        # pdb.set_trace()
        # C_h_text
        if trip[0] in C_h_all:
            okgtext_ids = C_h_all[trip[0]]
            # if len(okgtext_ids) > 32:
            #     pdb.set_trace()
            # random.shuffle(okgtext_ids)
            # pdb.set_trace()
            seq_i = 0
            for seq in okgtext_ids:
                # print(seq)
                C_h_text[i,seq_i,0:len(seq)] = np.array(seq)
                C_h_text_len[i,seq_i] = len(seq)
                C_h_text_mask[i,seq_i] = 1
                seq_i = seq_i + 1
                if seq_i >= okgEntitytext_max_num:
                    break
            # pdb.set_trace()
            if seq_i < okgEntitytext_max_num:
                seq_trip1 = data.rel2word[trip[1]]
                for seq_i_temp in range(seq_i, okgEntitytext_max_num):
                    # print(len(okgtext_ids[0]))
                    C_h_text[i, seq_i_temp, 0:len(seq_trip1)] = np.array(seq_trip1)
                    C_h_text_len[i, seq_i_temp] = len(seq_trip1)
                    C_h_text_mask[i, seq_i_temp] = 0
        else:
            seq_trip0 = data.ent2word[trip[0]]
            for seq_i_temp in range(okgEntitytext_max_num):
                C_h_text[i, seq_i_temp, 0:len(seq_trip0)] = np.array(seq_trip0)
                C_h_text_len[i, seq_i_temp] = len(seq_trip0)
                C_h_text_mask[i, seq_i_temp] = 0
            C_h_text_mask[i, 0] = 1

        # pdb.set_trace()
        # C_r_text
        if trip[1] >= true_rel_len:
            # pdb.set_trace()
            rel_1 = trip[1] - true_rel_len
        else:
            rel_1 = trip[1]
        if rel_1 in C_r_all:
            okgtext_ids_rel = C_r_all[rel_1]
            # random.shuffle(okgtext_ids_rel)

            seq_i_rel = 0
            for seq in okgtext_ids_rel:
                # print(seq)
                C_r_text[i, seq_i_rel, 0:len(seq)] = np.array(seq)
                C_r_text_len[i, seq_i_rel] = len(seq)
                C_r_text_mask[i, seq_i_rel] = 1
                seq_i_rel = seq_i_rel + 1
                if seq_i_rel >= okgEntitytext_max_num:
                    break
            # pdb.set_trace()
            if seq_i_rel < okgEntitytext_max_num:
                seq_trip0 = data.ent2word[trip[0]]
                for seq_i_rel_temp in range(seq_i_rel, okgEntitytext_max_num):
                    C_r_text[i, seq_i_rel_temp, 0:len(seq_trip0)] = np.array(seq_trip0)
                    C_r_text_len[i, seq_i_rel_temp] = len(seq_trip0)
                    C_r_text_mask[i, seq_i_rel_temp] = 0
        else:
            seq_trip1 = data.rel2word[trip[1]]
            for seq_i_rel_temp in range(okgEntitytext_max_num):
                C_r_text[i, seq_i_rel_temp, 0:len(seq_trip1)] = np.array(seq_trip1)
                C_r_text_len[i, seq_i_rel_temp] = len(seq_trip1)
                C_r_text_mask[i, seq_i_rel_temp] = 0
            C_r_text_mask[i, 0] = 1

        # pdb.set_trace()
        # S_okg_all
        if trip[0] in S_okg_all:
            okg_triples_text = S_okg_all[trip[0]]
            # pdb.set_trace()
            # random.shuffle(okg_triples_text)
            seq_i_s_okg = 0
            for seq in okg_triples_text:
                # print(seq)
                S_okg_text[i, seq_i_s_okg, 0:len(seq)] = np.array(seq)
                S_okg_text_len[i, seq_i_s_okg] = len(seq)
                S_okg_text_mask[i, seq_i_s_okg] = 1
                seq_i_s_okg = seq_i_s_okg + 1
                if seq_i_s_okg >= okgEntitytext_max_num:
                    break
            # pdb.set_trace()
            if seq_i_s_okg < okgEntitytext_max_num:
                for s_okg_temp_i in range(seq_i_s_okg, okgEntitytext_max_num):
                    S_okg_text[i, s_okg_temp_i, 0:len(okg_triples_text[0])] = np.array(okg_triples_text[0])
                    S_okg_text_len[i, s_okg_temp_i] = len(okg_triples_text[0])
                    S_okg_text_mask[i, s_okg_temp_i] = 0
        else:
            head_seq = data.ent2word[trip[0]]
            rel_seq = data.rel2word[trip[1]]
            tail_seq = data.ent2word[pos_ids[0]]
            triple_seq = []
            triple_seq.extend(head_seq)
            triple_seq.extend(rel_seq)
            triple_seq.extend(tail_seq)
            for s_okg_temp_i in range(okgEntitytext_max_num):
                S_okg_text[i, s_okg_temp_i, 0:len(triple_seq)] = np.array(triple_seq)
                S_okg_text_len[i, s_okg_temp_i] = len(triple_seq)
                S_okg_text_mask[i, s_okg_temp_i] = 0
            S_okg_text_mask[i, 0] = 1

        # pdb.set_trace()
        # S_kg_id
        if trip[0] in S_kg_all:
            # pdb.set_trace()
            kg_triples_id = S_kg_all[trip[0]]
            seq_i_s_kg = 0
            for kg_trip in kg_triples_id:
                # print(seq)
                S_kg_id[i, seq_i_s_kg] = np.array(kg_trip)
                S_kg_id_mask[i, seq_i_s_kg] = 1
                seq_i_s_kg = seq_i_s_kg + 1
                if seq_i_s_kg >= okgEntitytext_max_num:
                    break
            # pdb.set_trace()
            if seq_i_s_kg < okgEntitytext_max_num:
                for s_kg_temp_i in range(seq_i_s_kg, okgEntitytext_max_num):
                    S_kg_id[i, s_kg_temp_i] = np.array(kg_triples_id[0])
                    S_kg_id_mask[i, s_kg_temp_i] = 0
        else:
            kg_triple = [trip[0], trip[1], pos_ids[0]]
            for s_kg_temp_i in range(okgEntitytext_max_num):
                S_kg_id[i, s_kg_temp_i] = np.array(kg_triple)
                S_kg_id_mask[i, s_kg_temp_i] = 0
            S_kg_id_mask[i, 0] = 1
        # pdb.set_trace()
    samples = np.array(samples)
    e_batch, e_len = seq_batch(samples[:, 0], args, data.ent2word)
    r_batch, r_len = seq_batch(samples[:, 1], args, data.rel2word)

    return samples, labels, e_batch, e_len, r_batch, r_len,\
           C_h_text, C_h_text_len, C_h_text_mask, \
           C_r_text, C_r_text_len, C_r_text_mask, \
           S_okg_text, S_okg_text_len, S_okg_text_mask, \
           S_kg_id, S_kg_id_mask


def get_next_batch_test(head, rel, data, args, okgEntitytext_max_num=32):
    samples = []
    C_h_all = data.C_h_all
    C_r_all = data.C_r_all
    S_okg_all = data.S_okg_all
    S_kg_all = data.S_kg_all

    true_rel_len = len(data.rel2id) // 2

    pad_id = data.word2id['<PAD>']
    C_h_text = np.ones((len(head), okgEntitytext_max_num, 12), dtype=int) * pad_id
    C_h_text_len = np.zeros((len(head), okgEntitytext_max_num), dtype=int)
    C_h_text_mask = np.zeros((len(head), okgEntitytext_max_num), dtype=int)
    C_r_text = np.ones((len(head), okgEntitytext_max_num, 16), dtype=int) * pad_id
    C_r_text_len = np.zeros((len(head), okgEntitytext_max_num), dtype=int)
    C_r_text_mask = np.zeros((len(head), okgEntitytext_max_num), dtype=int)

    S_okg_text = np.ones((len(head), okgEntitytext_max_num, 24), dtype=int) * pad_id
    S_okg_text_len = np.zeros((len(head), okgEntitytext_max_num), dtype=int)
    S_okg_text_mask = np.zeros((len(head), okgEntitytext_max_num), dtype=int)

    S_kg_id = np.ones((len(head), okgEntitytext_max_num, 3), dtype=int) * pad_id
    S_kg_id_mask = np.zeros((len(head), okgEntitytext_max_num), dtype=int)

    for i in range(len(head)):
        # pdb.set_trace()
        trip = [head[i], rel[i]]
        samples.append([trip[0],trip[1]])

        if (trip[0], trip[1]) in data.label_graph:
            pos_ids = list(data.label_graph[(trip[0], trip[1])])
        else:
            pos_ids = [trip[0]]

        # C_h_text
        if trip[0] in C_h_all:
            okgtext_ids = C_h_all[trip[0]]
            seq_i = 0
            for seq in okgtext_ids:
                # print(seq)
                C_h_text[i, seq_i, 0:len(seq)] = np.array(seq)
                C_h_text_len[i, seq_i] = len(seq)
                C_h_text_mask[i, seq_i] = 1
                seq_i = seq_i + 1
                if seq_i >= okgEntitytext_max_num:
                    break
            # pdb.set_trace()
            if seq_i < okgEntitytext_max_num:
                for seq_i_temp in range(seq_i, okgEntitytext_max_num):
                    C_h_text[i, seq_i_temp, 0:len(okgtext_ids[0])] = np.array(okgtext_ids[0])
                    C_h_text_len[i, seq_i_temp] = len(okgtext_ids[0])
                    C_h_text_mask[i, seq_i_temp] = 0
        else:
            seq_trip0 = data.ent2word[trip[0]]
            for seq_i_temp in range(okgEntitytext_max_num):
                C_h_text[i, seq_i_temp, 0:len(seq_trip0)] = np.array(seq_trip0)
                C_h_text_len[i, seq_i_temp] = len(seq_trip0)
                C_h_text_mask[i, seq_i_temp] = 0

        # pdb.set_trace()
        # C_r_text
        if trip[1] >= true_rel_len:
            # pdb.set_trace()
            rel_1 = trip[1] - true_rel_len
        else:
            rel_1 = trip[1]
        if rel_1 in C_r_all:
            okgtext_ids_rel = C_r_all[rel_1]
            seq_i_rel = 0
            for seq in okgtext_ids_rel:
                # print(seq)
                C_r_text[i, seq_i_rel, 0:len(seq)] = np.array(seq)
                C_r_text_len[i, seq_i_rel] = len(seq)
                C_r_text_mask[i, seq_i_rel] = 1
                seq_i_rel = seq_i_rel + 1
                if seq_i_rel >= okgEntitytext_max_num:
                    break
            # pdb.set_trace()
            if seq_i_rel < okgEntitytext_max_num:
                for seq_i_rel_temp in range(seq_i_rel, okgEntitytext_max_num):
                    C_r_text[i, seq_i_rel_temp, 0:len(okgtext_ids_rel[0])] = np.array(okgtext_ids_rel[0])
                    C_r_text_len[i, seq_i_rel_temp] = len(okgtext_ids_rel[0])
                    C_r_text_mask[i, seq_i_rel_temp] = 0
        else:
            seq_trip1 = data.rel2word[trip[1]]
            for seq_i_rel_temp in range(okgEntitytext_max_num):
                C_r_text[i, seq_i_rel_temp, 0:len(seq_trip1)] = np.array(seq_trip1)
                C_r_text_len[i, seq_i_rel_temp] = len(seq_trip1)
                C_r_text_mask[i, seq_i_rel_temp] = 0

        # pdb.set_trace()
        # S_okg_all
        if trip[0] in S_okg_all:
            okg_triples_text = S_okg_all[trip[0]]
            seq_i_s_okg = 0
            for seq in okg_triples_text:
                # print(seq)
                S_okg_text[i, seq_i_s_okg, 0:len(seq)] = np.array(seq)
                S_okg_text_len[i, seq_i_s_okg] = len(seq)
                S_okg_text_mask[i, seq_i_s_okg] = 1
                seq_i_s_okg = seq_i_s_okg + 1
                if seq_i_s_okg >= okgEntitytext_max_num:
                    break
            # pdb.set_trace()
            if seq_i_s_okg < okgEntitytext_max_num:
                for s_okg_temp_i in range(seq_i_s_okg, okgEntitytext_max_num):
                    S_okg_text[i, s_okg_temp_i, 0:len(okg_triples_text[0])] = np.array(okg_triples_text[0])
                    S_okg_text_len[i, s_okg_temp_i] = len(okg_triples_text[0])
                    S_okg_text_mask[i, s_okg_temp_i] = 0
        else:
            head_seq = data.ent2word[trip[0]]
            rel_seq = data.rel2word[trip[1]]
            tail_seq = data.ent2word[pos_ids[0]]
            triple_seq = []
            triple_seq.extend(head_seq)
            triple_seq.extend(rel_seq)
            triple_seq.extend(tail_seq)
            for s_okg_temp_i in range(okgEntitytext_max_num):
                S_okg_text[i, s_okg_temp_i, 0:len(triple_seq)] = np.array(triple_seq)
                S_okg_text_len[i, s_okg_temp_i] = len(triple_seq)
                S_okg_text_mask[i, s_okg_temp_i] = 0

        # pdb.set_trace()
        # S_kg_id
        if trip[0] in S_kg_all:
            kg_triples_id = S_kg_all[trip[0]]
            seq_i_s_kg = 0
            for kg_trip in kg_triples_id:
                # print(seq)
                S_kg_id[i, seq_i_s_kg] = np.array(kg_trip)
                S_kg_id_mask[i, seq_i_s_kg] = 1
                seq_i_s_kg = seq_i_s_kg + 1
                if seq_i_s_kg >= okgEntitytext_max_num:
                    break
            # pdb.set_trace()
            if seq_i_s_kg < okgEntitytext_max_num:
                for s_kg_temp_i in range(seq_i_s_kg, okgEntitytext_max_num):
                    S_kg_id[i, s_kg_temp_i] = np.array(kg_triples_id[0])
                    S_kg_id_mask[i, s_kg_temp_i] = 0
        else:
            kg_triple = [trip[0], trip[1], pos_ids[0]]
            for s_kg_temp_i in range(okgEntitytext_max_num):
                S_kg_id[i, s_kg_temp_i] = np.array(kg_triple)
                S_kg_id_mask[i, s_kg_temp_i] = 0
        # pdb.set_trace()
    samples = np.array(samples)
    e_batch, e_len = seq_batch(samples[:, 0], args, data.ent2word)
    r_batch, r_len = seq_batch(samples[:, 1], args, data.rel2word)

    return samples, e_batch, e_len, r_batch, r_len,\
           C_h_text, C_h_text_len, C_h_text_mask, \
           C_r_text, C_r_text_len, C_r_text_mask, \
           S_okg_text, S_okg_text_len, S_okg_text_mask, \
           S_kg_id, S_kg_id_mask



def get_rank_entity(scores, tail, Hits, filter_ID):
    hits = np.ones((len(Hits)))
    hits_filter = np.ones((len(Hits)))
    scores = np.argsort(scores)
    rank = 1
    rank_filter = 1
    for i in range(scores.shape[0]):
        if scores[i] == tail:
            break
        else:
            rank += 1
            if scores[i] not in filter_ID:
                rank_filter += 1
    for i,r in enumerate(Hits):
        if rank>r: hits[i]=0
        else: break
    for i,r in enumerate(Hits):
        if rank_filter>r: hits_filter[i]=0
        else: break
    return rank, hits, rank_filter, hits_filter

def get_rank_mention(scores,clust,Hits,entid2clustid,filter_clustID):
    hits = np.ones((len(Hits)))
    # pdb.set_trace()
    scores = np.argsort(scores)
    rank = 1
    high_rank_clust = set()
    # pdb.set_trace()
    for i in range(scores.shape[0]):
        if scores[i] in clust: break
        else:
            if entid2clustid[scores[i]] not in high_rank_clust and entid2clustid[scores[i]] not in filter_clustID:
                rank+=1
                high_rank_clust.add(entid2clustid[scores[i]])
    for i,r in enumerate(Hits):
        if rank>r: hits[i]=0
        else: break
    return rank,hits

def get_rank_cluster(scores,clust,Hits,entid2clustid,filter_clustID):
    hits = np.ones((len(Hits)))
    scores = np.argsort(scores)
    all_rank = 0
    rank = 1
    tail_num = len(clust)
    high_rank_clust = set()
    # pdb.set_trace()
    for i in range(scores.shape[0]):
        if scores[i] in clust:
            all_rank = all_rank + rank
            tail_num = tail_num - 1
            if tail_num == 0:
                all_rank = all_rank /len(clust)
                break
        else:
            if entid2clustid[scores[i]] not in high_rank_clust and entid2clustid[scores[i]] not in filter_clustID:
                rank+=1
                high_rank_clust.add(entid2clustid[scores[i]])
    for i,r in enumerate(Hits):
        if all_rank>r: hits[i]=0
        else: break
    return rank,hits


def evaluate(model, entTotal, num_rels, test_trips, args, data):
    node_id = torch.arange(0, entTotal, dtype=torch.long)
    rel_id = torch.arange(0, num_rels, dtype=torch.long)
    H_Rank = []
    H_inv_Rank = []
    H_Hits = np.zeros((len(args.Hits)))
    H_Rank_filter = []
    H_inv_Rank_filter = []
    H_Hits_filter = np.zeros((len(args.Hits)))

    T_Rank = []
    T_inv_Rank = []
    T_Hits = np.zeros((len(args.Hits)))
    T_Rank_filter = []
    T_inv_Rank_filter = []
    T_Hits_filter = np.zeros((len(args.Hits)))

    head = test_trips[:, 0]
    rel = test_trips[:, 1]
    tail = test_trips[:, 2]
    id2ent = data.id2ent
    id2rel = data.id2rel
    # true_clusts_ent = data.true_clusts_ent
    # entid2clustid = data.entid2clustid
    ent_filter = data.label_filter
    bs = args.batch_size

    # edges_ent = torch.tensor(data.edges_ent,dtype=torch.long)
    # edges_rel = torch.tensor(data.edges_rel, dtype=torch.long)
    if args.use_cuda:
        node_id = node_id.cuda()
        rel_id = rel_id.cuda()
        # edges_ent = edges_ent.cuda()
        # edges_rel = edges_rel.cuda()

    # r_embed, ent_embed = model.get_embed(data.edges_ent, data.edges_rel, ents, rels, head, rel)
    # ent_embed = model.final_np_embeddings
    # r_embed = model.final_rp_embeddings

    test_scores = np.zeros((test_trips.shape[0], entTotal))
    n_batches = math.ceil(test_trips.shape[0] / bs)
    # for i in range(n_batches):
    #     ent = head[i * bs:min((i + 1) * bs, test_trips.shape[0])]
    #     ent = ent_embed[ent, :]
    #     r = rel[i * bs:min((i + 1) * bs, test_trips.shape[0])]
    #     r = r_embed[r, :]
    #     scores = model.get_scores(ent, r, ent_embed, ent.shape[0]).cpu().data.numpy()
    #     test_scores[i * bs:min((i + 1) * bs, test_trips.shape[0]), :] = scores

    for i in range(n_batches):
        # print(i)
        ent = head[i * bs:min((i + 1) * bs, test_trips.shape[0])]
        # ent = ent_embed[ent, :]
        r = rel[i * bs:min((i + 1) * bs, test_trips.shape[0])]
        # r = r_embed[r, :]
        samples, e_batch, e_len, r_batch, r_len, C_h_text, C_h_text_len, C_h_text_mask, \
        C_r_text, C_r_text_len, C_r_text_mask, S_okg_text, S_okg_text_len, S_okg_text_mask, \
        S_kg_id, S_kg_id_mask = get_next_batch_test(ent, r, data, args)

        samples = Variable(torch.from_numpy(samples))
        C_h_text = Variable(torch.LongTensor(torch.from_numpy(C_h_text)))
        C_h_text_len = Variable(torch.LongTensor(torch.from_numpy(C_h_text_len)))
        C_h_text_mask = Variable(torch.LongTensor(torch.from_numpy(C_h_text_mask)))
        C_r_text = Variable(torch.LongTensor(torch.from_numpy(C_r_text)))
        C_r_text_len = Variable(torch.LongTensor(torch.from_numpy(C_r_text_len)))
        C_r_text_mask = Variable(torch.LongTensor(torch.from_numpy(C_r_text_mask)))

        S_okg_text = Variable(torch.LongTensor(torch.from_numpy(S_okg_text)))
        S_okg_text_len = Variable(torch.LongTensor(torch.from_numpy(S_okg_text_len)))
        S_okg_text_mask = Variable(torch.LongTensor(torch.from_numpy(S_okg_text_mask)))

        S_kg_id = Variable(torch.LongTensor(torch.from_numpy(S_kg_id)))
        S_kg_id_mask = Variable(torch.LongTensor(torch.from_numpy(S_kg_id_mask)))

        if args.use_cuda:
            samples = samples.cuda()
            C_h_text = C_h_text.cuda()
            C_h_text_len = C_h_text_len.cuda()
            C_h_text_mask = C_h_text_mask.cuda()
            C_r_text = C_r_text.cuda()
            C_r_text_len = C_r_text_len.cuda()
            C_r_text_mask = C_r_text_mask.cuda()
            S_okg_text = S_okg_text.cuda()
            S_okg_text_len = S_okg_text_len.cuda()
            S_okg_text_mask = S_okg_text_mask.cuda()
            S_kg_id = S_kg_id.cuda()
            S_kg_id_mask = S_kg_id_mask.cuda()

        scores = model.get_embed(samples, e_batch, e_len, r_batch, r_len,
                                     C_h_text, C_h_text_len, C_h_text_mask,
                                     C_r_text, C_r_text_len, C_r_text_mask,
                                     S_okg_text, S_okg_text_len, S_okg_text_mask,
                                     S_kg_id, S_kg_id_mask, node_id, rel_id)
        test_scores[i * bs:min((i + 1) * bs, test_trips.shape[0]), :] = scores.cpu().data.numpy()


    for j in range(test_trips.shape[0]):
        print("Evaluation Phase: sample {}/{} total samples".format(j + 1, test_trips.shape[0]), end="\r")
        # pdb.set_trace()
        sample_scores = -test_scores[j, :]

        _filter = []
        if (head[j], rel[j]) in ent_filter: _filter = ent_filter[(head[j], rel[j])]


        if j % 2 == 1:
            H_r, H_h, H_r_filter, H_h_filter = get_rank_entity(sample_scores, tail[j], args.Hits, _filter)
            H_Rank.append(H_r)
            H_inv_Rank.append(1 / H_r)
            H_Hits += H_h

            H_Rank_filter.append(H_r_filter)
            H_inv_Rank_filter.append(1 / H_r_filter)
            H_Hits_filter += H_h_filter
        else:
            T_r, T_h, T_r_filter, T_h_filter = get_rank_entity(sample_scores, tail[j], args.Hits, _filter)
            T_Rank.append(T_r)
            T_inv_Rank.append(1 / T_r)
            T_Hits += T_h

            T_Rank_filter.append(T_r_filter)
            T_inv_Rank_filter.append(1 / T_r_filter)
            T_Hits_filter += T_h_filter

    print("\n")
    print("metrics \t MR \t MRR \t Hits@1 \t Hits@10 \t Hits@100")

    print("filterhead \t " + str(np.mean(np.array(H_Rank_filter))) + "\t" + str(np.mean(np.array(H_inv_Rank_filter))) + "\t"
          + str(H_Hits_filter[0] / len(H_Rank_filter)) + "\t" + str(H_Hits_filter[1] / len(H_Rank_filter)) + "\t"
          + str(H_Hits_filter[2] / len(H_Rank_filter)))
    print("filtertail \t " + str(np.mean(np.array(T_Rank_filter))) + "\t" + str(np.mean(np.array(T_inv_Rank_filter))) + "\t"
          + str(T_Hits_filter[0] / len(T_Rank_filter)) + "\t" + str(T_Hits_filter[1] / len(T_Rank_filter)) + "\t"
          + str(T_Hits_filter[2] / len(T_Rank_filter)))
    print("filteravg \t " + str((np.mean(np.array(H_Rank_filter)) + np.mean(np.array(T_Rank_filter))) / 2) + "\t"
          + str((np.mean(np.array(H_inv_Rank_filter)) + np.mean(np.array(T_inv_Rank_filter))) / 2) + "\t"
          + str((H_Hits_filter[0] + T_Hits_filter[0]) / (len(H_Rank_filter) + len(T_Rank_filter))) + "\t"
          + str((H_Hits_filter[1] + T_Hits_filter[1]) / (len(H_Rank_filter) + len(T_Rank_filter))) + "\t"
          + str((H_Hits_filter[2] + T_Hits_filter[2]) / (len(H_Rank_filter) + len(T_Rank_filter))))
    return (H_Hits_filter[0]+ T_Hits_filter[0]) / (len(H_Rank_filter) + len(T_Rank_filter)), \
           (H_Hits_filter[1]+ T_Hits_filter[1]) / (len(H_Rank_filter) + len(T_Rank_filter)),\
           (H_Hits_filter[2]+ T_Hits_filter[2]) / (len(H_Rank_filter) + len(T_Rank_filter))


def evaluate_final(model, entTotal, num_rels, test_trips, args, data):
    node_id = torch.arange(0, entTotal, dtype=torch.long)
    rel_id = torch.arange(0, num_rels, dtype=torch.long)
    H_Rank = []
    H_inv_Rank = []
    H_Hits = np.zeros((len(args.Hits)))
    H_Rank_filter = []
    H_inv_Rank_filter = []
    H_Hits_filter = np.zeros((len(args.Hits)))

    T_Rank = []
    T_inv_Rank = []
    T_Hits = np.zeros((len(args.Hits)))
    T_Rank_filter = []
    T_inv_Rank_filter = []
    T_Hits_filter = np.zeros((len(args.Hits)))

    head = test_trips[:, 0]
    rel = test_trips[:, 1]
    tail = test_trips[:, 2]
    id2ent = data.id2ent
    id2rel = data.id2rel
    # true_clusts_ent = data.true_clusts_ent
    # entid2clustid = data.entid2clustid
    ent_filter = data.label_filter
    bs = args.batch_size

    if args.use_cuda:
        node_id = node_id.cuda()
        rel_id = rel_id.cuda()

    test_scores = np.zeros((test_trips.shape[0], entTotal))
    n_batches = math.ceil(test_trips.shape[0] / bs)

    for i in range(n_batches):
        # print(i)
        ent = head[i * bs:min((i + 1) * bs, test_trips.shape[0])]
        # ent = ent_embed[ent, :]
        r = rel[i * bs:min((i + 1) * bs, test_trips.shape[0])]
        # r = r_embed[r, :]

        samples, e_batch, e_len, r_batch, r_len, C_h_text, C_h_text_len, C_h_text_mask, \
        C_r_text, C_r_text_len, C_r_text_mask, S_okg_text, S_okg_text_len, S_okg_text_mask, \
        S_kg_id, S_kg_id_mask = get_next_batch_test(ent, r, data, args)

        samples = Variable(torch.from_numpy(samples))
        C_h_text = Variable(torch.LongTensor(torch.from_numpy(C_h_text)))
        C_h_text_len = Variable(torch.LongTensor(torch.from_numpy(C_h_text_len)))
        C_h_text_mask = Variable(torch.LongTensor(torch.from_numpy(C_h_text_mask)))
        C_r_text = Variable(torch.LongTensor(torch.from_numpy(C_r_text)))
        C_r_text_len = Variable(torch.LongTensor(torch.from_numpy(C_r_text_len)))
        C_r_text_mask = Variable(torch.LongTensor(torch.from_numpy(C_r_text_mask)))

        S_okg_text = Variable(torch.LongTensor(torch.from_numpy(S_okg_text)))
        S_okg_text_len = Variable(torch.LongTensor(torch.from_numpy(S_okg_text_len)))
        S_okg_text_mask = Variable(torch.LongTensor(torch.from_numpy(S_okg_text_mask)))

        S_kg_id = Variable(torch.LongTensor(torch.from_numpy(S_kg_id)))
        S_kg_id_mask = Variable(torch.LongTensor(torch.from_numpy(S_kg_id_mask)))

        if args.use_cuda:
            samples = samples.cuda()
            C_h_text = C_h_text.cuda()
            C_h_text_len = C_h_text_len.cuda()
            C_h_text_mask = C_h_text_mask.cuda()
            C_r_text = C_r_text.cuda()
            C_r_text_len = C_r_text_len.cuda()
            C_r_text_mask = C_r_text_mask.cuda()
            S_okg_text = S_okg_text.cuda()
            S_okg_text_len = S_okg_text_len.cuda()
            S_okg_text_mask = S_okg_text_mask.cuda()
            S_kg_id = S_kg_id.cuda()
            S_kg_id_mask = S_kg_id_mask.cuda()

        scores = model.get_embed(samples, e_batch, e_len, r_batch, r_len,
                                 C_h_text, C_h_text_len, C_h_text_mask,
                                 C_r_text, C_r_text_len, C_r_text_mask,
                                 S_okg_text, S_okg_text_len, S_okg_text_mask,
                                 S_kg_id, S_kg_id_mask, node_id, rel_id)
        test_scores[i * bs:min((i + 1) * bs, test_trips.shape[0]), :] = scores.cpu().data.numpy()


    for j in range(test_trips.shape[0]):
        print("Evaluation Phase: sample {}/{} total samples".format(j + 1, test_trips.shape[0]), end="\r")
        # pdb.set_trace()
        sample_scores = -test_scores[j, :]

        _filter = []
        if (head[j], rel[j]) in ent_filter: _filter = ent_filter[(head[j], rel[j])]


        if j % 2 == 1:
            H_r, H_h, H_r_filter, H_h_filter = get_rank_entity(sample_scores, tail[j], args.Hits, _filter)
            H_Rank.append(H_r)
            H_inv_Rank.append(1 / H_r)
            H_Hits += H_h

            H_Rank_filter.append(H_r_filter)
            H_inv_Rank_filter.append(1 / H_r_filter)
            H_Hits_filter += H_h_filter
        else:
            T_r, T_h, T_r_filter, T_h_filter = get_rank_entity(sample_scores, tail[j], args.Hits, _filter)
            T_Rank.append(T_r)
            T_inv_Rank.append(1 / T_r)
            T_Hits += T_h

            T_Rank_filter.append(T_r_filter)
            T_inv_Rank_filter.append(1 / T_r_filter)
            T_Hits_filter += T_h_filter

    print("\n")
    print("metrics \t MR \t MRR \t Hits@1 \t Hits@10 \t Hits@100")
    print("rawhead \t " + str(np.mean(np.array(H_Rank))) + "\t" + str(np.mean(np.array(H_inv_Rank))) + "\t"
          + str(H_Hits[0] / len(H_Rank)) + "\t" + str(H_Hits[1] / len(H_Rank)) + "\t" + str(H_Hits[2] / len(H_Rank)))
    print("rawtail \t " + str(np.mean(np.array(T_Rank))) + "\t" + str(np.mean(np.array(T_inv_Rank))) + "\t"
          + str(T_Hits[0] / len(T_Rank)) + "\t" + str(T_Hits[1] / len(T_Rank)) + "\t" + str(T_Hits[2] / len(T_Rank)))
    print("rawavg \t " + str((np.mean(np.array(H_Rank)) + np.mean(np.array(T_Rank))) / 2) + "\t"
          + str((np.mean(np.array(H_inv_Rank)) + np.mean(np.array(T_inv_Rank))) / 2) + "\t"
          + str((H_Hits[0] + T_Hits[0]) / (len(H_Rank) + len(T_Rank))) + "\t"
          + str((H_Hits[1] + T_Hits[1]) / (len(H_Rank) + len(T_Rank))) + "\t"
          + str((H_Hits[2] + T_Hits[2]) / (len(H_Rank) + len(T_Rank))))

    print("filterhead \t " + str(np.mean(np.array(H_Rank_filter))) + "\t" + str(np.mean(np.array(H_inv_Rank_filter))) + "\t"
          + str(H_Hits_filter[0] / len(H_Rank_filter)) + "\t" + str(H_Hits_filter[1] / len(H_Rank_filter)) + "\t"
          + str(H_Hits_filter[2] / len(H_Rank_filter)))
    print("filtertail \t " + str(np.mean(np.array(T_Rank_filter))) + "\t" + str(np.mean(np.array(T_inv_Rank_filter))) + "\t"
          + str(T_Hits_filter[0] / len(T_Rank_filter)) + "\t" + str(T_Hits_filter[1] / len(T_Rank_filter)) + "\t"
          + str(T_Hits_filter[2] / len(T_Rank_filter)))
    print("filteravg \t " + str((np.mean(np.array(H_Rank_filter)) + np.mean(np.array(T_Rank_filter))) / 2) + "\t"
          + str((np.mean(np.array(H_inv_Rank_filter)) + np.mean(np.array(T_inv_Rank_filter))) / 2) + "\t"
          + str((H_Hits_filter[0] + T_Hits_filter[0]) / (len(H_Rank_filter) + len(T_Rank_filter))) + "\t"
          + str((H_Hits_filter[1] + T_Hits_filter[1]) / (len(H_Rank_filter) + len(T_Rank_filter))) + "\t"
          + str((H_Hits_filter[2] + T_Hits_filter[2]) / (len(H_Rank_filter) + len(T_Rank_filter))))

    with open('final_result.txt', 'a') as f_w:
        # f_w.write("metrics \t MR \t MRR \t Hits@1 \t Hits@10 \t Hits@100")
        f_w.write('************************************\n')
        f_w.write("rawhead \t " + str(np.mean(np.array(H_Rank))) + "\t" + str(np.mean(np.array(H_inv_Rank))) + "\t"
              + str(H_Hits[0] / len(H_Rank)) + "\t" + str(H_Hits[1] / len(H_Rank)) + "\t" + str(H_Hits[2] / len(H_Rank)) + "\n")
        f_w.write("rawtail \t " + str(np.mean(np.array(T_Rank))) + "\t" + str(np.mean(np.array(T_inv_Rank))) + "\t"
              + str(T_Hits[0] / len(T_Rank)) + "\t" + str(T_Hits[1] / len(T_Rank)) + "\t" + str(T_Hits[2] / len(T_Rank)) + '\n')
        f_w.write("rawavg \t " + str((np.mean(np.array(H_Rank)) + np.mean(np.array(T_Rank))) / 2) + "\t"
              + str((np.mean(np.array(H_inv_Rank)) + np.mean(np.array(T_inv_Rank))) / 2) + "\t"
              + str((H_Hits[0] + T_Hits[0]) / (len(H_Rank) + len(T_Rank))) + "\t"
              + str((H_Hits[1] + T_Hits[1]) / (len(H_Rank) + len(T_Rank))) + "\t"
              + str((H_Hits[2] + T_Hits[2]) / (len(H_Rank) + len(T_Rank)))+ '\n')

        f_w.write("filterhead \t " + str(np.mean(np.array(H_Rank_filter))) + "\t" + str(np.mean(np.array(H_inv_Rank_filter))) + "\t"
              + str(H_Hits_filter[0] / len(H_Rank_filter)) + "\t" + str(H_Hits_filter[1] / len(H_Rank_filter)) + "\t"
              + str(H_Hits_filter[2] / len(H_Rank_filter)) + '\n')
        f_w.write("filtertail \t " + str(np.mean(np.array(T_Rank_filter))) + "\t" + str(np.mean(np.array(T_inv_Rank_filter))) + "\t"
              + str(T_Hits_filter[0] / len(T_Rank_filter)) + "\t" + str(T_Hits_filter[1] / len(T_Rank_filter)) + "\t"
              + str(T_Hits_filter[2] / len(T_Rank_filter)) + '\n')
        f_w.write("filteravg \t " + str((np.mean(np.array(H_Rank_filter)) + np.mean(np.array(T_Rank_filter))) / 2) + "\t"
              + str((np.mean(np.array(H_inv_Rank_filter)) + np.mean(np.array(T_inv_Rank_filter))) / 2) + "\t"
              + str((H_Hits_filter[0] + T_Hits_filter[0]) / (len(H_Rank_filter) + len(T_Rank_filter))) + "\t"
              + str((H_Hits_filter[1] + T_Hits_filter[1]) / (len(H_Rank_filter) + len(T_Rank_filter))) + "\t"
              + str((H_Hits_filter[2] + T_Hits_filter[2]) / (len(H_Rank_filter) + len(T_Rank_filter))) + '\n')



    return (H_Hits[0]+ T_Hits[0]) / (len(H_Rank) + len(T_Rank)), \
           (H_Hits[1]+ T_Hits[1]) / (len(H_Rank) + len(T_Rank)),\
           (H_Hits[2]+ T_Hits[2]) / (len(H_Rank) + len(T_Rank))



