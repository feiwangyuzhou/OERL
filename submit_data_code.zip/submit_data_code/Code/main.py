#### Import all the supporting classes

import argparse
import numpy as np
from utils import *
from data import load_data
from ConvE import ConvEParam
# from kge.model import KgeModel
# from kge.util.io import load_checkpoint
import torch
import torch.nn as nn
import json
import pdb

import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID" 
# os.environ["CUDA_VISIBLE_DEVICES"] = "0"

def main(args):
	if torch.cuda.is_available(): args.use_cuda = True
	else: args.use_cuda = False
	data = load_data(args)
	args.pad_id = data.word2id['<PAD>']
	args.num_nodes = max([x for x in data.id2ent]) + 1
	args.num_rels = max([x for x in data.id2rel]) + 1


	model = ConvEParam(args, data.embed_matrix, data.rel2word, data.ent2word)

	if args.use_cuda:
		model.cuda()

	if args.resume:
		resume_model = torch.load('output/best_model.pth')

		model_dict = model.state_dict()
		pretrained_dict = resume_model.state_dict()
		pretrained_dict = {k: v for k, v in pretrained_dict.items() if k in model_dict}
		model_dict.update(pretrained_dict)
		model.load_state_dict(model_dict)

		start_epoch = 0
		model.eval()
		_ = evaluate(model, args.num_nodes, args.num_rels, data.valid_trips, args, data)
	else:
		start_epoch = 0
	print("start_epoch = " + str(start_epoch))

	optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
	scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode = 'max',factor = 0.995, patience = 10)

	train_pairs = list(data.label_graph.keys())
	train_id = np.arange(len(train_pairs))

	node_id = torch.arange(0, args.num_nodes, dtype=torch.long)
	rel_id = torch.arange(0, args.num_rels, dtype=torch.long)
	# pdb.set_trace()
	# print(node_id)
	# edges_ent = torch.tensor(data.edges_ent,dtype=torch.long)
	# edges_rel = torch.tensor(data.edges_rel, dtype=torch.long)
	if args.use_cuda:
		# edges_ent = edges_ent.cuda()
		# edges_rel = edges_rel.cuda()
		node_id = node_id.cuda()
		rel_id = rel_id.cuda()

	# best_MR = 20000
	# best_MRR = 0
	best_epoch = 0
	best_hit1 = 0.0
	best_hit10 = 0.0
	best_hit50 = 0.0
	count = 0
	# file_num = 1
	# print(file_num)
	# train_index_list = [i for i in range(file_num)]
	for epoch in range(args.n_epochs):
		model.train()
		if count >= args.early_stop: break
		epoch_loss = 0
		permute = np.random.permutation(train_id)
		train_id = train_id[permute]
		n_batches = math.ceil(train_id.shape[0] / args.batch_size)

		t1 = time.time()
		for i in range(n_batches):
			# pdb.set_trace()
			id_list = train_id[i*args.batch_size:(i+1)*args.batch_size]
			samples, labels, e_batch, e_len, r_batch, r_len,\
			C_h_text, C_h_text_len, C_h_text_mask, \
			C_r_text, C_r_text_len, C_r_text_mask, S_okg_text, S_okg_text_len, S_okg_text_mask, \
			S_kg_id, S_kg_id_mask = get_next_batch(id_list, data, args, train_pairs)

			samples = Variable(torch.from_numpy(samples))
			labels = Variable(torch.from_numpy(labels).float())
			C_h_text = Variable(torch.LongTensor(torch.from_numpy(C_h_text)))
			C_h_text_len = Variable(torch.LongTensor(torch.from_numpy(C_h_text_len)))
			C_h_text_mask = Variable(torch.LongTensor(torch.from_numpy(C_h_text_mask)))
			C_r_text = Variable(torch.LongTensor(torch.from_numpy(C_r_text)))
			C_r_text_len = Variable(torch.LongTensor(torch.from_numpy(C_r_text_len)))
			C_r_text_mask = Variable(torch.LongTensor(torch.from_numpy(C_r_text_mask)))

			S_okg_text = Variable(torch.LongTensor(torch.from_numpy(S_okg_text)))
			S_okg_text_len = Variable(torch.LongTensor(torch.from_numpy(S_okg_text_len)))
			S_okg_text_mask = Variable(torch.LongTensor(torch.from_numpy(S_okg_text_mask)))

			S_kg_id = Variable(torch.LongTensor(torch.from_numpy(S_kg_id)))
			S_kg_id_mask = Variable(torch.LongTensor(torch.from_numpy(S_kg_id_mask)))

			if args.use_cuda:
				samples = samples.cuda()
				labels = labels.cuda()
				C_h_text = C_h_text.cuda()
				C_h_text_len = C_h_text_len.cuda()
				C_h_text_mask = C_h_text_mask.cuda()
				C_r_text = C_r_text.cuda()
				C_r_text_len = C_r_text_len.cuda()
				C_r_text_mask = C_r_text_mask.cuda()
				S_okg_text = S_okg_text.cuda()
				S_okg_text_len = S_okg_text_len.cuda()
				S_okg_text_mask = S_okg_text_mask.cuda()
				S_kg_id = S_kg_id.cuda()
				S_kg_id_mask = S_kg_id_mask.cuda()

			optimizer.zero_grad()
			loss = model.get_loss(samples, labels, e_batch, e_len, r_batch, r_len,
								  C_h_text, C_h_text_len, C_h_text_mask,
								  C_r_text, C_r_text_len, C_r_text_mask,
								  S_okg_text, S_okg_text_len, S_okg_text_mask,
								  S_kg_id, S_kg_id_mask, node_id, rel_id)

			loss.backward()
			print("batch {}/{} batches, batch_loss: {}".format(i,n_batches,(loss.data).cpu().numpy()),end='\r')
			torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_norm)
			optimizer.step()
			epoch_loss += (loss.data).cpu().numpy()
		print("epoch {}/{} total epochs, epoch_loss: {}".format(epoch,args.n_epochs,epoch_loss/n_batches))

		if epoch > -1:
			if epoch%args.eval_epoch==0:
				model.eval()
				hit1, hit10, hit50 = evaluate(model, args.num_nodes, args.num_rels, data.valid_trips, args, data)
				# pdb.set_trace()
				if hit1 > best_hit1:
					count = 0
				elif (hit1 == best_hit1) and (hit10 > best_hit10):
					count = 0
				elif (hit1 == best_hit1) and (hit10 == best_hit10) and (hit50 > best_hit50):
					count = 0
				else: count += 1

				if count == 0:
					best_hit1 = hit1
					best_hit10 = hit10
					best_hit50 = hit50
					best_epoch = epoch
					# torch.save(model, 'output/best_model.pth')
					torch.save(data, 'output/data.pth')
					torch.save({'state_dict': model.state_dict(), 'epoch': epoch}, 'output/best_model.pth')

				print("Best hit1: {}, Best epoch: {}".format(best_hit1, best_epoch))
				scheduler.step(best_epoch)


	### Get Embeddings
	print("Test Set Evaluation ---")
	checkpoint = torch.load('output/best_model.pth')
	model.load_state_dict(checkpoint['state_dict'])
	# model = torch.load('output/best_model.pth')
	model.eval()
	hit1, hit10, hit100 = evaluate_final(model, args.num_nodes, args.num_rels, data.test_trips, args, data)



if __name__ == '__main__':
	parser = argparse.ArgumentParser(description='CaRe: Canonicalization Infused Representations for Open KGs')

	### Model and Dataset choice
	parser.add_argument('-dataset', dest='dataset', default='OLPBENCH-nKG',help='Dataset Choice')
	parser.add_argument('-okg_dataset', dest='okg_dataset', default='OLPBENCH-OKG', help='Dataset Choice')

	### Data Paths
	parser.add_argument('-data_path',       dest='data_path',       default='../data', 			help='Data folder')

	#### Hyper-parameters
	parser.add_argument('-nfeats',      dest='nfeats',       default=300,   type=int,       help='Embedding Dimensions')
	parser.add_argument('-nheads',      dest='nheads',       default=3,     type=int,       help='multi-head attantion in GAT')
	parser.add_argument('-num_layers',  dest='num_layers',   default=1,     type=int,       help='No. of layers in encoder network')
	parser.add_argument('-bidirectional',  dest='bidirectional',   default=True,     type=bool,       help='type of encoder network')
	parser.add_argument('-poolType',    dest='poolType',     default='last',choices=['last','max','mean'], help='pooling operation for encoder network')
	parser.add_argument('-dropout',     dest='dropout',      default=0.5,   type=float,     help='Dropout')
	parser.add_argument('-reg_param',   dest='reg_param',    default=0.0,   type=float,     help='regularization parameter')
	parser.add_argument('-lr',          dest='lr',           default=0.001, type=float,     help='learning rate')
	parser.add_argument('-p_norm',      dest='p_norm',       default=1,     type=int,       help='TransE scoring function')
	parser.add_argument('-batch_size',  dest='batch_size',   default=128,   type=int,       help='batch size for training')
	parser.add_argument('-neg_samples', dest='neg_samples',  default=10,    type=int,       help='No of Negative Samples for TransE')
	parser.add_argument('-n_epochs',    dest='n_epochs',     default=500,   type=int,       help='maximum no. of epochs')
	parser.add_argument('-grad_norm',   dest='grad_norm',    default=1.0,   type=float,     help='gradient clipping')
	parser.add_argument('-eval_epoch',  dest='eval_epoch',   default=1,     type=int,       help='Interval for evaluating on validation dataset')
	parser.add_argument('-Hits',        dest='Hits',         default= [1,10,100],           help='Choice of n in Hits@n')
	parser.add_argument('-early_stop',  dest='early_stop',   default=20,    type=int,       help='Stopping training after validation performance stops improving')
	parser.add_argument('-ranking', dest='ranking', default='entity_ranking', choices=['mention_ranking', 'entity_ranking','cluster_ranking'], help='Ranking Choice')

	parser.add_argument('-get_context_embeddings', dest='get_context_embeddings', default=False, type=bool, help='If False, is similar to Care model')
	parser.add_argument('-pretrainedEmbedding', dest='pretrainedEmbedding', default=False, type=bool, help='If True, is to load pretrained embedding')
	parser.add_argument('-mode', dest='mode', default='train', choices=['train', 'eval'])
	parser.add_argument('-resume', dest='resume', default=False, type=bool)

	parser.add_argument('-scoreMode', dest='scoreMode', default='ConvE', choices=['ConvE', 'TransE', 'ComplEx'])
	parser.add_argument('-aggregation_flag', dest='aggregation_flag', default='gat', choices=['gat', 'mean'])

	parser.add_argument("-alpha", dest="alpha", default=0.2, type=float, help="LeakyRelu alphs for SpGAT layer")

	parser.add_argument("--bert_model", dest='bert_model',
						default='bert-base-uncased', type=str,
						help="Bert pre-trained model selected in the list: bert-base-uncased, "
							 "bert-large-uncased, bert-base-cased, bert-base-multilingual, bert-base-chinese.")
	parser.add_argument("--do_lower_case", action='store_true', help="Set this flag if you are using an uncased model.")


	args = parser.parse_args()


	args.data_files = {
	'ent2id_path'       : args.data_path + '/' + args.dataset + '/kg_entity2id.txt',
	'rel2id_path'       : args.data_path + '/' + args.dataset + '/kg_relation2id.txt',
	'train_trip_path'   : args.data_path + '/' + args.dataset + '/kg_train.txt',
	'test_trip_path'    : args.data_path + '/' + args.dataset + '/kg_test.txt',
	'valid_trip_path'   : args.data_path + '/' + args.dataset + '/kg_valid.txt',
	'id2okgEntitytext_path': args.data_path + '/' + args.dataset + '/stopword_reidnewkgid_2_Okgids_entity_text.json',
	'id2okgRelationtext_path': args.data_path + '/' + args.dataset + '/stopword_final_kgid_2_Okgids_relation_text.json',
	'glove_path'        : '../glove/glove.6B.300d.txt',
	'okg_ent2id_path': args.data_path + '/' + args.okg_dataset + '/entity2id.txt',
	'okg_rel2id_path': args.data_path + '/' + args.okg_dataset + '/relation2id.txt',
	'okg_train': args.data_path + '/' + args.okg_dataset + '/train.txt',
	'sd_kgtext2okgtext_ent': './final/sd_kgtext2okgtext_ent.json',
	'sd_kgtext2okgtext_rel': './final/sd_kgtext2okgtext_rel.json',
	's_okg_kgtext2okgtext': './final/s_okg_kgtext2okgtext.json',
	's_kg_kgtext2okgtext': './final/s_kg_kgtext2kgtext.json'
	}


	args.model_path = "output/"+"ConvE"
	# args.pretrained_model_path = "output/CaRe/" + "ConvE" + "-" + args.CN + "_modelpath.pth"
	args.pretrained_model_path = args.model_path + str(1)

	print(args.get_context_embeddings)
	print(args.resume)
	print(args.aggregation_flag)

	# 加上这个，能保持训练时结果与测试时结果相近
	SEED = 1
	np.random.seed(SEED)
	torch.manual_seed(SEED)
	torch.cuda.manual_seed_all(SEED)
	torch.backends.cudnn.deterministic = True
	torch.backends.cudnn.benchmark = False

	# main(args)
	# only_evaluate(args)
	main(args)
