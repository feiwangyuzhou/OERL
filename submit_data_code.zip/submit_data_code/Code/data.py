import pathlib
import numpy as np
import json
import pdb
from seach import tokenOverlap, getent_term_freq_cluster
import nltk
# nltk.download('stopwords')
# from nltk.corpus import stopwords
from SimilarityScore import BertEncoder
import math

class load_data():
    def __init__(self, args):
        # SEED = 1
        # np.random.seed(SEED)

        self.args = args
        self.data_files = self.args.data_files

        self.fetch_data()
        
    def get_phrases(self,file_path):
        f = open(file_path,"r").readlines()
        phrase2id = {}
        id2phrase = {}
        word2id = set()

        for line in f:
            temp = line.strip().split("\t")
            phrase = temp[0]
            ID = temp[1]
            # phrase, ID = line.strip().split("\t")
            phrase2id[phrase] = int(ID)
            id2phrase[int(ID)] = phrase
            for word in phrase.split():
                word2id.add(word)
        return phrase2id,id2phrase,word2id

    def get_phrases_rel(self, file_path):
        f = open(file_path,"r").readlines()
        phrase2id = {}
        id2phrase = {}
        word2id = set()
        # pdb.set_trace()
        num_rel_ID = len(f)

        for line in f:
            temp = line.strip().split("\t")
            phrase = temp[0]
            ID = temp[1]
            # phrase, ID = line.strip().split("\t")
            phrase2id[phrase] = int(ID)
            id2phrase[int(ID)] = phrase
            for word in phrase.split():
                word2id.add(word)

            # r_inv = "inverse of " + phrase
            r_inv = "inversed " + phrase
            if r_inv not in phrase2id:
                phrase2id[r_inv] = int(num_rel_ID)
                id2phrase[int(num_rel_ID)] = r_inv
                num_rel_ID += 1

        word2id.add("inversed")
        return phrase2id,id2phrase,word2id

    def get_phrase2word(self,phrase2id,word2id):
        phrase2word = {}
        for phrase in phrase2id:
            words = []
            for word in phrase.split(): words.append(word2id[word])
            phrase2word[phrase2id[phrase]] = words
        # return key: phrase_id, value: word2id list
        return phrase2word

    def get_phrase2word_okg(self,phrase2id,word2id):
        phrase2word = {}
        for phrase in phrase2id:
            words = []
            for word in phrase.split(): words.append(word2id[word])
            phrase2word[phrase] = words
        # return key: phrase_id, value: word2id list
        return phrase2word

    def getid2okgEntitytext(self,file_path, okgword2id):
        with open(file_path, 'r') as load_f:
            temp = json.load(load_f)
            max_num = 0
            id2okgEntitytext = {}
            for key in temp:
                id2okgEntitytext[int(key)] = temp[key]
                if len(temp[key]) > max_num:
                    max_num = len(temp[key])
                for seq in temp[key]:
                    for word in seq.split():
                        okgword2id.add(word)

        return id2okgEntitytext, max_num, okgword2id



    
    def get_word_embed(self,word2id,GLOVE_PATH):
        word_embed = {}
        if pathlib.Path(GLOVE_PATH).is_file():
            print("utilizing pre-trained word embeddings")
            with open(GLOVE_PATH, encoding="utf8") as f:
                for line in f:
                    word, vec = line.split(' ', 1)
                    if word in word2id:
                        word_embed[word2id[word]] = np.fromstring(vec, sep=' ')
        else: print("word embeddings are randomly initialized")

        wordkeys = word2id.values()
        a = [words for words in wordkeys if words not in word_embed]
        for word in a:
            word_embed[word] = np.random.normal(size = 300)

        self.embed_matrix  = np.zeros((len(word_embed),300))
        for word in word_embed:
            self.embed_matrix[word] = word_embed[word]

    def get_train_triples(self, triples_path, rel2id, id2rel):
        trip_list = []
        label_graph = {}
        self.label_filter = {}
        f = open(triples_path, "r").readlines()
        for trip in f:
            trip = trip.strip().split('\t')
            e1, r, e2 = int(trip[0]), int(trip[1]), int(trip[2])
            r_inv = "inversed " + id2rel[r]
            # r_inv = "inverse of " + id2rel[r]
            # if r_inv not in rel2id:
            #     ID = len(rel2id)
            #     rel2id[r_inv] = ID

            r_inv = rel2id[r_inv]

            if (e1, r) not in label_graph:
                label_graph[(e1, r)] = set()
            label_graph[(e1, r)].add(e2)

            if (e2, r_inv) not in label_graph:
                label_graph[(e2, r_inv)] = set()
            label_graph[(e2, r_inv)].add(e1)

            if (e1, r) not in self.label_filter:
                self.label_filter[(e1, r)] = set()
            self.label_filter[(e1, r)].add(e2)

            if (e2, r_inv) not in self.label_filter:
                self.label_filter[(e2, r_inv)] = set()
            self.label_filter[(e2, r_inv)].add(e1)

            trip_list.append([e1, r, e2])
            trip_list.append([e2, r_inv, e1])
        return np.array(trip_list), label_graph

    def get_train_triples_okg(self, triples_path, id2ent_okg, id2rel_okg):
        # pdb.set_trace()
        label_graph_outgoing = {}
        label_graph_incoming = {}
        f = open(triples_path, "r").readlines()
        for trip in f:
            trip = trip.strip().split('\t')
            e1_id, r_id, e2_id = int(trip[0]), int(trip[1]), int(trip[2])
            e1 = id2ent_okg[e1_id]
            e2 = id2ent_okg[e2_id]
            r = id2rel_okg[r_id]

            if e1 not in label_graph_outgoing:
                label_graph_outgoing[e1] = set()
            label_graph_outgoing[e1].add((e1, r, e2))

            if e2 not in label_graph_incoming:
                label_graph_incoming[e2] = set()
            label_graph_incoming[e2].add((e1, r, e2))
        return label_graph_outgoing, label_graph_incoming



    def get_test_triples(self, triples_path, rel2id, id2rel):
        trip_list = []
        f = open(triples_path, "r").readlines()
        for trip in f:
            trip = trip.strip().split('\t')
            e1, r, e2 = int(trip[0]), int(trip[1]), int(trip[2])
            # r_inv = "inverse of " + id2rel[r]
            r_inv = "inversed " + id2rel[r]
            trip_list.append([e1, r, e2])
            trip_list.append([e2, rel2id[r_inv], e1])
        return np.array(trip_list)

    def getstopword(self):
        # pdb.set_trace()
        # stopword = set(stopwords.words('english'))
        f = open("../data/stopword.txt", "r").readlines()
        stopword = set()
        for word in f:
            word = word.strip()
            stopword.add(word)
        # pdb.set_trace()
        return stopword

    
    def fetch_data(self):
        self.rel2id,self.id2rel,self.word2id = self.get_phrases_rel(self.data_files["rel2id_path"])
        self.ent2id,self.id2ent,self.ent_word2id = self.get_phrases(self.data_files["ent2id_path"])
        # pdb.set_trace()
        self.train_trips, self.label_graph = self.get_train_triples(self.data_files["train_trip_path"], self.rel2id, self.id2rel)
        self.valid_trips = self.get_test_triples(self.data_files["valid_trip_path"], self.rel2id, self.id2rel)
        self.test_trips = self.get_test_triples(self.data_files["test_trip_path"], self.rel2id, self.id2rel)

        self.rel2id_okg, self.id2rel_okg, self.okg_word2id = self.get_phrases_rel(self.data_files["okg_rel2id_path"])
        self.ent2id_okg, self.id2ent_okg, self.okg_ent_word2id = self.get_phrases(self.data_files["okg_ent2id_path"])

        self.word2id = self.word2id.union(self.ent_word2id)
        self.word2id = self.word2id.union(self.okg_word2id)
        self.word2id = self.word2id.union(self.okg_ent_word2id)
        self.word2id = {word: index for index, word in enumerate(list(self.word2id))}
        self.word2id['<PAD>'] = len(self.word2id)
        self.rel2word = self.get_phrase2word(self.rel2id, self.word2id)
        self.ent2word = self.get_phrase2word(self.ent2id, self.word2id)
        self.ent_okgtext2wordids = self.get_phrase2word_okg(self.ent2id_okg, self.word2id)
        self.rel_okgtext2wordids = self.get_phrase2word_okg(self.rel2id_okg, self.word2id)

        self.get_word_embed(self.word2id, self.data_files["glove_path"])

        self.C_h_all = self.get_kgid2okgtext_wordid(self.data_files["sd_kgtext2okgtext_ent"], self.ent2id, self.ent_okgtext2wordids)
        self.C_r_all = self.get_kgid2okgtext_wordid(self.data_files["sd_kgtext2okgtext_rel"], self.rel2id, self.rel_okgtext2wordids)
        self.S_okg_all = self.S_okg_kgid2okgtext_wordid(self.data_files["s_okg_kgtext2okgtext"], self.ent2id, self.ent_okgtext2wordids, self.rel_okgtext2wordids)
        # self.searchrelatedmentions()
        # self.SemanticDenoising('first/kgtext2okgtext_ent.json', "ent")
        # self.SemanticDenoising('first/kgtext2okgtext_rel.json', "rel")
        # self.structuralConnection("second/sd_kgtext2okgtext_ent.json", "second/sd_kgtext2okgtext_rel.json")
        # pdb.set_trace()

    def get_kgid2okgtext_wordid(self, file_path, ent2id, ent_okgtext2wordids):
        # pdb.set_trace()
        with open(file_path, 'r') as load_f:
            temp = json.load(load_f)
            max_num = 0
            kgid2okgtext_wordid = {}
            for key in temp:
                # pdb.set_trace()
                key_id = ent2id[key]
                temp_wordids= []
                for okgtext in temp[key]:
                    okgtext_wordids = ent_okgtext2wordids[okgtext]
                    temp_wordids.append(okgtext_wordids)
                    if len(okgtext_wordids) > max_num:
                        max_num = len(okgtext_wordids)
                if len(temp_wordids) > 0:
                    kgid2okgtext_wordid[key_id] = temp_wordids
                # if len(temp[key]) > max_num:
                #     max_num = len(temp[key])
        print(max_num)
        return kgid2okgtext_wordid

    def S_okg_kgid2okgtext_wordid(self, file_path, ent2id, ent_okgtext2wordids, rel_okgtext2wordids):
        # pdb.set_trace()
        with open(file_path, 'r') as load_f:
            temp = json.load(load_f)
            max_num = 0
            S_okg_kgid2okgtext_wordid = {}
            for key in temp:
                key_id = ent2id[key]
                temp_wordids= []
                for trip in temp[key]:
                    head = ent_okgtext2wordids[trip[0]]
                    rel = rel_okgtext2wordids[trip[1]]
                    tail = ent_okgtext2wordids[trip[2]]
                    trip_wordid = []
                    trip_wordid.extend(head)
                    trip_wordid.extend(rel)
                    trip_wordid.extend(tail)
                    temp_wordids.append(trip_wordid)
                    if len(trip_wordid) > max_num:
                        max_num = len(trip_wordid)
                S_okg_kgid2okgtext_wordid[key_id] = temp_wordids
        print(max_num)
        # pdb.set_trace()
        return S_okg_kgid2okgtext_wordid


    def S_kg_kgid2okgtext_kgid(self, file_path, ent2id, rel2id):
        # pdb.set_trace()
        with open(file_path, 'r') as load_f:
            temp = json.load(load_f)
            # max_num = 0
            kgid2triple_kgid = {}
            for key in temp:
                key_id = ent2id[key]
                triple_kgid = []
                triples_text = temp[key]
                for trip_text in triples_text:
                    e1 = ent2id[trip_text[0]]
                    rel = rel2id[trip_text[1]]
                    e2 = ent2id[trip_text[2]]
                    triple_kgid.append([e1, rel, e2])
                    # self.train_trips.append([e1, rel, e2])
                    if (e1 != key_id) and (e2 != key_id):
                        pdb.set_trace()
                kgid2triple_kgid[key_id]=triple_kgid
                # pdb.set_trace()
                # if len(temp[key]) > max_num:
                #     max_num = len(temp[key])
        return kgid2triple_kgid

    def searchrelatedmentions(self):
        # pdb.set_trace()
        # search related mentions
        stopword = self.getstopword()
        ent_list_kg = list(self.ent2id.keys())
        rel_list_kg = []
        for id in range(len(self.id2rel.keys())//2):
            rel_list_kg.append(self.id2rel[id])
        ent_list_okg = list(self.ent2id_okg.keys())
        rel_list_okg = list(self.rel2id_okg.keys())
        ent_term_freq, ent_cluster = getent_term_freq_cluster(ent_list_okg, stopword)
        _, ent_num_degree = tokenOverlap(ent_list_kg, ent_term_freq, ent_cluster, stopword, name="ent")
        rel_term_freq, rel_cluster = getent_term_freq_cluster(rel_list_okg, stopword)
        _, rel_num_degree = tokenOverlap(rel_list_kg, rel_term_freq, rel_cluster, stopword, name="rel")
        pdb.set_trace()

    def SemanticDenoising(self, file_path, name):
        self.SimilarityScore = BertEncoder(self.args)
        # Semantic Denoising with Bert
        with open(file_path, 'r') as load_f:
            temp = json.load(load_f)
            sd_num_degree = {}
            sd_kgtext2okgtext_ent = {}
            iiiiiiiiiiiiiiiiii=0
            for key in temp:
                print(iiiiiiiiiiiiiiiiii)
                iiiiiiiiiiiiiiiiii += 1
                okgmentions_final = []
                okgmentions_ori = list(set(temp[key]))

                # pdb.set_trace()
                bs = 128
                n_batches = math.ceil(len(okgmentions_ori) / bs)
                scores = []
                for i in range(n_batches):
                    # pdb.set_trace()
                    okgmentions_batch = okgmentions_ori[i * bs:min((i + 1) * bs, len(okgmentions_ori))]
                    score = self.SimilarityScore(key, okgmentions_batch)
                    score = score*(-1)
                    scores.extend(score.cpu().data.numpy())

                # pdb.set_trace()
                scores_pos = np.argsort(scores)
                if len(scores_pos) > 32:
                    num_len= 32
                else:
                    num_len= len(scores_pos)
                # pdb.set_trace()
                for okgmention_pos in scores_pos[:num_len]:
                    okgmentions_final.append(okgmentions_ori[okgmention_pos])

                if num_len != len(okgmentions_final):
                    pdb.set_trace()

                if num_len > 0:
                    sd_kgtext2okgtext_ent[key] = okgmentions_final

                if num_len not in sd_num_degree:
                    sd_num_degree[num_len] = 1
                else:
                    sd_num_degree[num_len] += 1

        # pdb.set_trace()
        with open('sd_kgtext2okgtext_' + name + '.json', "w", encoding='utf-8') as f2:
            json.dump(sd_kgtext2okgtext_ent, f2)

        with open('sd_num_degree_' + name + '.json', "w", encoding='utf-8') as f2:
            json.dump(sd_num_degree, f2)

    def structuralConnection(self, file_path_ent, file_path_rel):
        # pdb.set_trace()
        with open(file_path_ent, 'r') as load_f:
            temp_ent = json.load(load_f)
            okgtext2kgtext_ent = {}
            for key_ent in temp_ent:
                okgmentions_ent = temp_ent[key_ent]
                for okgmention_ent in okgmentions_ent:
                    if okgmention_ent in okgtext2kgtext_ent:
                        # pdb.set_trace()
                        old_key_ent = okgtext2kgtext_ent[okgmention_ent]
                        if len(temp_ent[old_key_ent]) > 32:
                            temp_ent[old_key_ent].remove(okgmention_ent)
                            okgtext2kgtext_ent[okgmention_ent] = key_ent
                        else:
                            temp_ent[key_ent].remove(okgmention_ent)
                    else:
                        okgtext2kgtext_ent[okgmention_ent] = key_ent
        # pdb.set_trace()
        with open(file_path_rel, 'r') as load_f:
            temp_rel = json.load(load_f)
            okgtext2kgtext_rel = {}
            for key_rel in temp_rel:
                okgmentions_rel = temp_rel[key_rel]
                for okgmention_rel in okgmentions_rel:
                    if okgmention_rel in okgtext2kgtext_rel:
                        # pdb.set_trace()
                        old_key_rel = okgtext2kgtext_rel[okgmention_rel]
                        if len(temp_rel[old_key_rel]) > 32:
                            temp_rel[old_key_rel].remove(okgmention_rel)
                            okgtext2kgtext_rel[okgmention_rel] = key_rel
                        else:
                            temp_rel[key_rel].remove(okgmention_rel)
                    else:
                        okgtext2kgtext_rel[okgmention_rel] = key_rel


        label_graph_outgoing, label_graph_incoming = self.get_train_triples_okg(self.data_files["okg_train"], self.id2ent_okg, self.id2rel_okg)
        # pdb.set_trace()
        S_okg = {}
        for key in temp_ent:
            okgmentions_ori = temp_ent[key]
            S_okg_key = set()
            for okgmention in okgmentions_ori:
                if okgmention in label_graph_outgoing:
                    okgmention_outgoing = label_graph_outgoing[okgmention]
                    S_okg_key = S_okg_key.union(okgmention_outgoing)
                if okgmention in label_graph_incoming:
                    okgmention_incoming = label_graph_incoming[okgmention]
                    S_okg_key = S_okg_key.union(okgmention_incoming)
            if len(S_okg_key) > 0:
                S_okg[key] = list(S_okg_key)

        # pdb.set_trace()
        final_S_okg = {}
        S_kg = {}
        for key in S_okg:
            triples_all = S_okg[key]
            S_kg_key = []
            S_okg_key = []
            for triple in triples_all:
                trip_e1 = triple[0]
                trip_rel = triple[1]
                trip_e2 = triple[2]

                if (trip_e1 in okgtext2kgtext_ent) and (trip_e2 in okgtext2kgtext_ent) and (trip_rel in okgtext2kgtext_rel):
                    # pdb.set_trace()
                    S_okg_key.append((triple[0], triple[1], triple[2]))
                    kg_e1 = okgtext2kgtext_ent[trip_e1]
                    kg_e2 = okgtext2kgtext_ent[trip_e2]
                    kg_rel = okgtext2kgtext_rel[trip_rel]

                    if kg_e1 == key:
                        S_kg_key.append((kg_e1, kg_rel, kg_e2))
                    elif kg_e2 == key:
                        S_kg_key.append((kg_e1, kg_rel, kg_e2))

            if len(S_kg_key) > 0:
                S_kg[key] = S_kg_key
            if len(S_okg_key) > 32:
                final_S_okg[key] = S_okg_key[:32]
            elif len(S_okg_key) > 0:
                final_S_okg[key] = S_okg_key
            # else:
            #     pdb.set_trace()

        # pdb.set_trace()
        with open('s_okg_kgtext2okgtext.json', "w", encoding='utf-8') as f2:
            json.dump(final_S_okg, f2)

        with open('s_kg_kgtext2kgtext.json', "w", encoding='utf-8') as f2:
            json.dump(S_kg, f2)


