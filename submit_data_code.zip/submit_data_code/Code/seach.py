import nltk
# nltk.download('wordnet')
from nltk.corpus import wordnet   #Import wordnet from the NLTK
import pdb, itertools
import numpy as np
import json

# from nltk.stem import WordNetLemmatizer
from nltk.stem import PorterStemmer
import re


def getsynsets(name):
    syn = []
    # ant = list()
    for synset in wordnet.synsets(name):
        for lemma in synset.lemmas():
            syn.append(lemma.name())  # add the synonyms
            # if lemma.antonyms():  # When antonyms are available, add them into the list
            #     ant.append(lemma.antonyms()[0].name())
    # print('Synonyms: ' + str(syn))
    # print('Antonyms: ' + str(ant))
    return syn

def unique(l):
    return list(set(l))

def getent_term_freq_cluster(ent_list, stopwords):
    # wnl = WordNetLemmatizer()
    pst = PorterStemmer()
    ent_term_freq = {}
    for ent in ent_list:
        for tok in ent.split():
            tok = pst.stem(tok)
            if tok not in stopwords:
                # tok = wnl.lemmatize(tok, 'n')
                # pdb.set_trace()
                if tok not in ent_term_freq:
                    ent_term_freq[tok] = 0
                ent_term_freq[tok] = ent_term_freq[tok] + 1
    # pdb.set_trace()
    cluster = {}
    for ent in ent_list:
        for tok in ent.split():
            tok = pst.stem(tok)
            if tok not in stopwords:
                # tok = wnl.lemmatize(tok, 'n')
                if tok not in cluster:
                    cluster[tok] = set()
                cluster[tok].add(ent)

    return ent_term_freq, cluster

def tokenOverlap(search_ents, ent_term_freq, cluster, stopwords, name):
    # pdb.set_trace()
    # wnl = WordNetLemmatizer()
    pst = PorterStemmer()
    ent2idfTok = {}
    kgtext2okgtext_ent={}
    kgtext2syns_ent = {}
    num_degree = {}
    iiiiiii=0
    for target_ent in search_ents:
        print(iiiiiii)
        iiiiiii = iiiiiii + 1
        # pdb.set_trace()
        target_ent_syns = getsynsets(target_ent)
        target_ent_syns.append(target_ent)
        kgtext2syns_ent[target_ent] = target_ent_syns
        target_ent_syns = set(target_ent_syns)

        for e1 in target_ent_syns:
            Candidate_cluster = {}
            for word in e1.split():
                # word = wnl.lemmatize(word, 'n')
                word = pst.stem(word)
                if word in cluster:
                    Candidate_cluster[word] = cluster[word]
            # pdb.set_trace()
            for rep, clust in Candidate_cluster.items():
                # pdb.set_trace()
                for e2 in clust:
                    # tokens1 = set([wnl.lemmatize(e11, 'n') for e11 in e1.split()]) - set(stopwords)
                    # tokens2 = set([wnl.lemmatize(e22, 'n') for e22 in e2.split()]) - set(stopwords)
                    # pdb.set_trace()
                    pattern = re.compile('[0-9]+')
                    match = pattern.findall(e2)
                    if match:
                        # pdb.set_trace()
                        continue
                    tokens1 = set([pst.stem(e11) for e11 in e1.split()]) - set(stopwords)
                    tokens2 = set([pst.stem(e22) for e22 in e2.split()]) - set(stopwords)

                    intersect = tokens1.intersection(tokens2)
                    union = tokens1.union(tokens2)

                    num, den = 0.0, 0.0
                    for ele in intersect:
                        if ele not in ent_term_freq:
                            ent_term_freq[ele] = 1
                        num += 1.0 / np.log(1 + ent_term_freq[ele])
                    for ele in union:
                        if ele not in ent_term_freq:
                            ent_term_freq[ele] = 1
                        den += 1.0 / np.log(1 + ent_term_freq[ele])

                    score = num / den if den != 0 else 0
                    if score > 0.15:
                        if target_ent not in ent2idfTok:
                            ent2idfTok[target_ent] = []
                        ent2idfTok[target_ent].append(str(score))

                        if target_ent not in kgtext2okgtext_ent:
                            kgtext2okgtext_ent[target_ent] = []
                        kgtext2okgtext_ent[target_ent].append(e2)
        # pdb.set_trace()
        if target_ent in kgtext2okgtext_ent:
            num_len = len(kgtext2okgtext_ent[target_ent])
            if num_len not in num_degree:
                num_degree[num_len] = 1
            else:
                num_degree[num_len] += 1
        else:
            print("zero")
            if 0 not in num_degree:
                num_degree[0] = 1
            else:
                num_degree[0] += 1
            # pdb.set_trace()

    # pdb.set_trace()
    with open('first/ent2idfTok_'+name+'.json', "w", encoding='utf-8') as f2:
        json.dump(ent2idfTok, f2)
    with open('first/kgtext2okgtext_'+name+'.json', "w", encoding='utf-8') as f2:
        json.dump(kgtext2okgtext_ent, f2)
    with open('first/kgtext2syns_'+name+'.json', "w", encoding='utf-8') as f2:
        json.dump(kgtext2syns_ent, f2)
    with open('first/num_degree_'+name+'.json', "w", encoding='utf-8') as f2:
        json.dump(num_degree, f2)

    return ent2idfTok, num_degree
