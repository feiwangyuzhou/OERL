import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
import pdb

class Similarity(nn.Module):
    """
    Dot product or cosine similarity
    """

    def __init__(self, temp):
        super().__init__()
        self.temp = temp
        self.cos = nn.CosineSimilarity(dim=-1)

    def forward(self, x, y):
        return self.cos(x, y) / self.temp

class aggregationGAT(nn.Module):
    """
    Sparse version GAT layer, similar to https://arxiv.org/abs/1710.10903
    """

    def __init__(self, in_features, out_features, dropout, alpha, concat=False):
        super(aggregationGAT, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.alpha = alpha
        self.concat = concat

        # self.W = nn.Parameter(torch.zeros(size=(in_features, out_features)))
        # nn.init.xavier_normal_(self.W.data, gain=1.414)

        self.a = nn.Parameter(torch.zeros(size=(1, out_features*2)))
        nn.init.xavier_normal_(self.a.data, gain=1.414)

        self.dropout = nn.Dropout(dropout)
        self.leakyrelu = nn.LeakyReLU(self.alpha)
        self.softmax = nn.Softmax(dim=1)

        self.sim = Similarity(temp=0.05)

    def forward(self, sub_embed, np_embed_batchs, okgtext_mask):
        # pdb.set_trace()
        batch_size, text_num = np_embed_batchs.size(0), np_embed_batchs.size(1)
        powers = self.sim(sub_embed.view(batch_size*text_num, -1), np_embed_batchs.view(batch_size*text_num, -1))
        assert not torch.isnan(powers).any()
        edge_e = torch.exp(powers)
        assert not torch.isnan(edge_e).any()

        edge_e = edge_e.view(batch_size, text_num)
        # edge_e = self.dropout(edge_e)

        # pdb.set_trace()
        e_rowsum = torch.sum(edge_e, dim=1)
        e_rowsum[e_rowsum == 0.0] = 1e-12
        # e_rowsum: N x 1
        attention = edge_e.div(e_rowsum.unsqueeze(1))

        okgtext_mask = okgtext_mask.view(-1, text_num)
        attention = attention * okgtext_mask
        # pdb.set_trace()
        # np_embed_batchs_W = np_embed_batchs.view(batch_size, text_num, -1)
        h_prime = torch.sum(attention.unsqueeze(-1) * np_embed_batchs, dim=1)
        # h_prime: N x out
        assert not torch.isnan(h_prime).any()

        if self.concat:
            # if this layer is not last layer,
            return F.elu(h_prime)
        else:
            # if this layer is last layer,
            return h_prime




