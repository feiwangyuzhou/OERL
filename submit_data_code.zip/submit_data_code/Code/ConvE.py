from utils import *
from encoder import GRUEncoder
from cn_variants import aggregationGAT
from data import load_data
import torch
import torch.nn as nn
import pdb

class ConvEParam(nn.Module):
    def __init__(self, args, embed_matrix, rel2words, ent2word, entity_embedder=None, relation_embedder=None, okgEntitytext_max_num=None):
        super(ConvEParam, self).__init__()
        self.args = args
        self.rel2words = rel2words
        self.ent2word = ent2word
        self.phrase_embed_model = GRUEncoder(embed_matrix, self.args)

        self.aggreGAT = aggregationGAT(self.args.nfeats, self.args.nfeats, self.args.dropout, self.args.alpha)
        # self.aggreGAT2 = aggregationGAT(self.args.nfeats, self.args.nfeats, self.args.dropout, self.args.alpha)


        if entity_embedder is None:
            self.np_embeddings = nn.Embedding(self.args.num_nodes, self.args.nfeats)
            nn.init.xavier_normal_(self.np_embeddings.weight.data)
            self.rp_embeddings = nn.Embedding(self.args.num_rels, self.args.nfeats)
            nn.init.xavier_normal_(self.rp_embeddings.weight.data)
        else:
            # self.np_embeddings = nn.Parameter(entity_embedder)
            # self.rp_embeddings = nn.Parameter(relation_embedder)
            # pdb.set_trace()
            self.np_embeddings = nn.Embedding(self.args.num_nodes, self.args.nfeats)
            self.np_embeddings.weight.data = entity_embedder
            self.rp_embeddings = nn.Embedding(self.args.num_rels, self.args.nfeats)
            self.rp_embeddings.weight.data = relation_embedder

        self.np_context_embeddings = nn.Embedding(self.args.num_nodes, self.args.nfeats)
        nn.init.xavier_normal_(self.np_context_embeddings.weight.data)

        # self.final_np_embeddings = nn.Parameter(torch.randn(self.args.num_nodes, self.args.nfeats))
        # self.final_rp_embeddings = nn.Parameter(torch.randn(self.args.num_rels, self.args.nfeats))

        self.inp_drop = torch.nn.Dropout(self.args.dropout)
        self.hidden_drop = torch.nn.Dropout(self.args.dropout)
        self.feature_map_drop = torch.nn.Dropout2d(self.args.dropout)
        self.loss = torch.nn.BCELoss()

        self.conv1 = torch.nn.Conv2d(1, 32, (3, 3))
        self.bn0 = torch.nn.BatchNorm2d(1)
        self.bn1 = torch.nn.BatchNorm2d(32)
        self.bn2 = torch.nn.BatchNorm1d(self.args.nfeats)
        self.register_parameter('b', nn.Parameter(torch.zeros(self.args.num_nodes)))
        self.fc = torch.nn.Linear(51968, self.args.nfeats)

        self.bias1 = nn.Parameter(torch.zeros(size=(self.args.nfeats, 1)))
        self.bias2 = nn.Parameter(torch.zeros(size=(self.args.nfeats, 1)))
        self.biasb = nn.Parameter(torch.zeros(size=(1, 1)))
        nn.init.xavier_uniform_(self.bias1.data, gain=1.414)
        nn.init.xavier_uniform_(self.bias2.data, gain=1.414)
        nn.init.xavier_uniform_(self.biasb.data, gain=1.414)

        self.fc_C_h = torch.nn.Linear(self.args.nfeats*2, self.args.nfeats)
        self.fc_S_kg = torch.nn.Linear(self.args.nfeats * 3, self.args.nfeats)


    def get_scores(self, ent, rel, ent_embed, batch_size):
        # pdb.set_trace()
        ent = ent.view(-1, 1, 20, 60)
        rel = rel.view(-1, 1, 10, 60)

        stacked_inputs = torch.cat([ent, rel], 2)

        stacked_inputs = self.bn0(stacked_inputs)
        x = self.inp_drop(stacked_inputs)
        x = self.conv1(x)
        x = self.bn1(x)
        x = F.relu(x)
        x = self.feature_map_drop(x)
        x = x.view(batch_size, -1)
        # pdb.set_trace()
        x = self.fc(x)
        x = self.hidden_drop(x)
        x = self.bn2(x)
        x = F.relu(x)
        # pdb.set_trace()
        x = torch.mm(x, ent_embed.transpose(1, 0))
        x += self.b.expand_as(x)
        return x

    def aggregation(self, C_h_np_embed_batch, np_embed_batchs, okgtext_mask):
        if self.args.aggregation_flag == 'mean':
            np_embed_batchs = np_embed_batchs * okgtext_mask.unsqueeze(2)
            phrase_encode_2 = torch.mean(np_embed_batchs, dim=1)
        else:  # GAT
            phrase_encode_2 = self.aggreGAT(C_h_np_embed_batch, np_embed_batchs, okgtext_mask)

        return phrase_encode_2


    def get_embed(self, samples, e_batch, e_len, r_batch, r_len,
                                 C_h_text, C_h_text_len, C_h_text_mask,
                                 C_r_text, C_r_text_len, C_r_text_mask,
                                 S_okg_text, S_okg_text_len, S_okg_text_mask,
                                 S_kg_id, S_kg_id_mask, node_id, rel_id):

        batch_size, max_num = C_h_text.size(0), C_h_text.size(1)
        np_embed = self.np_embeddings(node_id)
        rp_embed = self.rp_embeddings(rel_id)

        # pdb.set_trace()
        sub_embed = np_embed[samples[:, 0]]
        e_batch, e_len = seq_batch(samples[:, 0].cpu().numpy(), self.args, self.ent2word)
        np_embed_batch = self.phrase_embed_model(e_batch, e_len)

        sub_embed = sub_embed + np_embed_batch

        C_h_text = C_h_text.view(-1, C_h_text.size(-1))
        C_h_text_len = C_h_text_len.view(-1)
        C_h_embed_batchs = self.phrase_embed_model(C_h_text, C_h_text_len)
        C_h_embed_batchs = C_h_embed_batchs.view(batch_size, max_num, -1)
        C_h_np_embed_batch = sub_embed.unsqueeze(1).expand_as(C_h_embed_batchs).contiguous()
        # pdb.set_trace()
        # C_h_embed_batchs = torch.cat((C_h_np_embed_batch, C_h_embed_batchs),dim=-1)
        # C_h_embed_batchs = self.fc_C_h(C_h_embed_batchs)
        C_h_embed = self.aggregation(C_h_np_embed_batch,C_h_embed_batchs, C_h_text_mask)
        #
        S_okg_text = S_okg_text.view(-1, S_okg_text.size(-1))
        S_okg_text_len = S_okg_text_len.view(-1)
        S_okg_embed_batchs = self.phrase_embed_model(S_okg_text, S_okg_text_len)
        S_okg_embed_batchs = S_okg_embed_batchs.view(batch_size, max_num, -1)
        S_okg_np_embed_batch = sub_embed.unsqueeze(1).expand_as(S_okg_embed_batchs).contiguous()

        # 注意这里是一致的attention，但均是与concept不一样的attention
        S_okg_embed = self.aggregation(S_okg_np_embed_batch, S_okg_embed_batchs, S_okg_text_mask)
        sub_embed = torch.cat((sub_embed, np_embed_batch, C_h_embed, S_okg_embed), dim=-1)

        rel_embed = rp_embed[samples[:, 1]]
        r_batch, r_len = seq_batch(samples[:, 1].cpu().numpy(), self.args, self.rel2words)
        rp_embed_batch = self.phrase_embed_model(r_batch, r_len)

        # rel_embed = rel_embed + rp_embed_batch
        # # pdb.set_trace()
        # C_r_text = C_r_text.view(-1, C_r_text.size(-1))
        # C_r_text_len = C_r_text_len.view(-1)
        # C_r_embed_batchs = self.phrase_embed_model(C_r_text, C_r_text_len)
        # C_r_embed_batchs = C_r_embed_batchs.view(batch_size, max_num, -1)
        # C_r_rp_embed_batch = rel_embed.unsqueeze(1).expand_as(C_r_embed_batchs).contiguous()
        # # C_r_embed_batchs = torch.cat((C_r_rp_embed_batch, C_r_embed_batchs), dim=-1)
        # # C_r_embed_batchs = self.fc_C_h(C_r_embed_batchs)
        # C_r_embed = self.aggregation(C_r_rp_embed_batch, C_r_embed_batchs, C_r_text_mask)

        rel_embed = torch.cat((rel_embed, rp_embed_batch), dim=-1)

        scores = self.get_scores(sub_embed, rel_embed, np_embed, len(samples))

        return scores


    def get_loss(self, samples, labels, e_batch, e_len, r_batch, r_len,
                      C_h_text, C_h_text_len, C_h_text_mask,
                      C_r_text, C_r_text_len, C_r_text_mask,
                      S_okg_text, S_okg_text_len, S_okg_text_mask,
                      S_kg_id, S_kg_id_mask, node_id, rel_id):

        scores = self.get_embed(samples, e_batch, e_len, r_batch, r_len,
                                     C_h_text, C_h_text_len, C_h_text_mask,
                                     C_r_text, C_r_text_len, C_r_text_mask,
                                     S_okg_text, S_okg_text_len, S_okg_text_mask,
                                     S_kg_id, S_kg_id_mask, node_id, rel_id)

        pred = F.sigmoid(scores)
        predict_loss = self.loss(pred, labels)

        return predict_loss
