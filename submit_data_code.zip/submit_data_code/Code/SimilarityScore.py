import torch
import torch.nn as nn
from transformers import BertTokenizer
from transformers import BertModel
import pdb

class BertEncoder(nn.Module):
    def __init__(self, args):
        super(BertEncoder, self).__init__()
        self.args = args
        self.tokenizer = BertTokenizer.from_pretrained(args.bert_model, do_lower_case=args.do_lower_case)
        self.bertmodel = BertModel.from_pretrained(args.bert_model)
        # self.fc2 = torch.nn.Linear(768, 300)
        self.cos = nn.CosineSimilarity(dim=-1)
        # for param in self.bertmodel.parameters():
        #     param.requires_grad = False

        if self.args.use_cuda:
            self.bertmodel.cuda()

    def convert_examples_to_features(self, mention, seq_length=32):
        batch_input_ids = []
        batch_input_mask = []
        batch_input_type_ids = []
        for (ex_index, example) in enumerate(mention):
            # pdb.set_trace()
            tokens_a = self.tokenizer.tokenize(example)

            tokens = []
            tokens.append("[CLS]")
            tokens.extend(tokens_a)
            tokens.append("[SEP]")
            input_type_ids = [0] * len(tokens)

            input_ids = self.tokenizer.convert_tokens_to_ids(tokens)

            # The mask has 1 for real tokens and 0 for padding tokens. Only real
            # tokens are attended to.
            input_mask = [1] * len(input_ids)

            # Zero-pad up to the sequence length.
            while len(input_ids) < seq_length:
                input_ids.append(0)
                input_mask.append(0)
                input_type_ids.append(0)

            assert len(input_ids) == seq_length
            assert len(input_mask) == seq_length
            assert len(input_type_ids) == seq_length

            batch_input_ids.append(input_ids)
            batch_input_mask.append(input_mask)
            batch_input_type_ids.append(input_type_ids)

        # pdb.set_trace()
        batch_input_ids = torch.tensor(batch_input_ids, dtype=torch.long)
        batch_input_mask = torch.tensor(batch_input_mask, dtype=torch.long)
        batch_input_type_ids = torch.tensor(batch_input_type_ids, dtype=torch.long)

        # if args.use_cuda:
        if self.args.use_cuda:
            batch_input_ids = batch_input_ids.cuda()
            batch_input_mask = batch_input_mask.cuda()
            batch_input_type_ids = batch_input_type_ids.cuda()

        return batch_input_ids, batch_input_mask, batch_input_type_ids

    def getBertembedding(self, mention):
        # pdb.set_trace()
        input_ids, input_mask, input_type_ids = self.convert_examples_to_features(mention)
        outputs = self.bertmodel(input_ids, token_type_ids=None, attention_mask=input_mask)
        pooled_output = outputs.pooler_output
        # pooled_output = self.fc2(pooled_output)
        return pooled_output

    def forward(self, key, okgmention):
        # pdb.set_trace()
        key_embed = self.getBertembedding([key])
        okgmention_embed = self.getBertembedding(okgmention)
        # pdb.set_trace()
        similarityscore = self.cos(key_embed, okgmention_embed)
        return similarityscore
